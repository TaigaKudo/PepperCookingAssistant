package io.github.TaigaKudo.dto;

public record StockRegisterResponse() {

}
