package io.github.TaigaKudo.auth.exception;

public class IngredientCategoryNotFoundException extends RuntimeException {

	public IngredientCategoryNotFoundException(String message) {
		super(message);
	}
}
