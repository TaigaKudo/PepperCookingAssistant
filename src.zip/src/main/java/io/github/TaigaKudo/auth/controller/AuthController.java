package io.github.TaigaKudo.auth.controller;

import jakarta.validation.Valid;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.github.TaigaKudo.auth.dto.LoginResult;
import io.github.TaigaKudo.auth.dto.RefreshResult;
import io.github.TaigaKudo.auth.exception.AuthenticationException;
import io.github.TaigaKudo.auth.service.AuthService;
import io.github.TaigaKudo.dto.LoginRequest;
import io.github.TaigaKudo.dto.RegisterRequest;
import io.github.TaigaKudo.dto.TokenResponse;
import io.github.TaigaKudo.security.RefreshTokenProperties;

@RestController
@RequestMapping("/auth")
public class AuthController {

	private final AuthService authService;
	private final RefreshTokenProperties refreshTokenProperties;
	
	public AuthController(
			AuthService authService,
			RefreshTokenProperties refreshTokenProperties
			) {
		this.authService = authService;
		this.refreshTokenProperties = refreshTokenProperties;
	}
	
	@GetMapping("/csrf")
	public ResponseEntity<Void> csrf(CsrfToken csrfToken){
		// 実際にtokenにアクセスすることでCookieを作成させる
		csrfToken.getToken();
		return ResponseEntity.noContent().build();
	}
	
	@PostMapping("/login")
	public ResponseEntity<TokenResponse> login(@Valid @RequestBody LoginRequest request){
		LoginResult result = authService.login(request);
		
		ResponseCookie refreshTokenCookie = ResponseCookie
				.from("refreshToken", result.refreshToken())
				.httpOnly(true)
				.secure(refreshTokenProperties.cookieSecure())
				.path("/auth")
				.maxAge(refreshTokenProperties.expiration())
				.sameSite("Lax")
				.build();
		
		return ResponseEntity
				.ok()
				.header(HttpHeaders.SET_COOKIE, refreshTokenCookie.toString())
				.body(new TokenResponse(result.accessToken()));
	}
	
	@PostMapping("/refresh")
	public ResponseEntity<TokenResponse> refresh(
			@CookieValue(name = "refreshToken", required = false) String refreshToken
			){
		if(refreshToken == null || refreshToken.isBlank()) {
			throw new AuthenticationException("Refresh Tokenがありません");
		}
		
		RefreshResult result = authService.refresh(refreshToken);
		
		ResponseCookie refreshTokenCookie = ResponseCookie
				.from("refreshToken", result.refreshToken())
				.httpOnly(true)
				.secure(refreshTokenProperties.cookieSecure())
				.path("/auth")
				.maxAge(refreshTokenProperties.expiration())
				.sameSite("Lax")
				.build();
		
		return ResponseEntity
				.ok()
				.header(HttpHeaders.SET_COOKIE, refreshTokenCookie.toString())
				.body(new TokenResponse(result.accessToken()));
	}
	
	@PostMapping("/logout")
	public ResponseEntity<Void> logout(@CookieValue(name = "refreshToken", required = false) String refreshToken){
		
		// すでにリフレッシュトークンが切れていても疑似ログアウトさせる
		if(refreshToken != null && !refreshToken.isBlank()) {
			authService.logout(refreshToken);
		}
		
		ResponseCookie deleteCookie = ResponseCookie
				.from("refreshToken", "")
				.httpOnly(true)
				.secure(refreshTokenProperties.cookieSecure())
				.path("/auth")
				.maxAge(0)
				.sameSite("Lax")
				.build();
		
		return ResponseEntity
				.noContent()
				.header(HttpHeaders.SET_COOKIE, deleteCookie.toString())
				.build();
	}
	
	@PostMapping("/register")
	public ResponseEntity<Void> register(
			@Valid @RequestBody RegisterRequest request
			){
		authService.register(request);
		
		return ResponseEntity.noContent().build();
	}
}
